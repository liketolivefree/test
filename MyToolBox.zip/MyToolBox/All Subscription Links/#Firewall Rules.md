#singbox(core)
**Necessary for getting and updating the Rules, testing Proxies, and connecting with TUN:
D:\bortable\sing\sing-box.exe				all	tcp	[name: sing-tun (D:\bortable\sing\sing-box.exe)]

====================================
#ClashVerge
**Necessary for getting and updating Proxies and Rules, testing them, and connecting with TUN:
C:\Program Files\Clash Verge\verge-mihomo.exe		all	tcp	[name: sing-tun]

====================================
#MihimoParty
**Necessary for getting and updating Proxies and Rules, testing them, and connecting with TUN_working with the Main Core:
C:\Program Files\Mihomo Party\resources\sidecar\mihomo.exe		all	tcp	[name: sing-tun (C:\Program Files\Mihomo Party\resources\sidecar\mihomo.exe)]

**Necessary for getting and updating Proxies and Rules, testing them, and connecting with TUN_working with the Smart Core:
C:\Program Files\Mihomo Party\resources\sidecar\mihomo-smart.exe	all	tcp	[name: sing-tun (C:\Program Files\Mihomo Party\resources\sidecar\mihomo-smart.exe)]

====================================
#Oblivion
C:\Program Files\oblivion-desktop\resources\assets\bin\oblivion-helper\oblivion-helper.exe	all	tcp	[name: sing-tun (C:\Program Files\oblivion-desktop\resources\assets\bin\oblivion-helper\oblivion-helper.exe)]
`C:\Program Files\oblivion-desktop\resources\assets\bin\oblivion-helper\oblivion-helper.exe	all	udp	[name: sing-tun (C:\Program Files\oblivion-desktop\resources\assets\bin\oblivion-helper\oblivion-helper.exe)]`
C:\Users\nam\AppData\Roaming\oblivion-desktop\oblivion-helper.exe		all	tcp	[name: sing-tun (C:\Users\nam\AppData\Roaming\oblivion-desktop\oblivion-helper.exe)]
`C:\Users\nam\AppData\Roaming\oblivion-desktop\oblivion-helper.exe		all	udp	[name: sing-tun (C:\Users\nam\AppData\Roaming\oblivion-desktop\oblivion-helper.exe)]`

C:\Program Files\oblivion-desktop\resources\assets\bin\warp-plus.exe		all	tcp	[name: warp-plus]
`C:\Program Files\oblivion-desktop\resources\assets\bin\warp-plus.exe		all	udp	[name: warp-plus]`
C:\Users\nam\AppData\Roaming\oblivion-desktop\warp-plus.exe		all	tcp	[name: warp-plus]
`C:\Users\nam\AppData\Roaming\oblivion-desktop\warp-plus.exe		all	udp	[name: warp-plus]`
====================================
#Nekosub:
**Necessary for updating Subs and testing them:
D:\bortable\neko-sub\nekobox.exe			public/private	tcp	[name: nekoray]
`D:\bortable\neko-sub\nekobox.exe			public/private	`udp`	[name: nekoray]`

**Necessary for connecting with TUN:
D:\bortable\neko-sub\nekobox_core			all	tcp	[name: sing-tun (D:\bortable\neko-sub\nekobox_core)]
D:\bortable\neko-sub\nekobox_core.exe			public/private	tcp	[name: nekobox_core]
`D:\bortable\neko-sub\nekobox_core.exe			public/private	udp	[name: nekobox_core]`

====================================
#Throne:
**Necessary for updating Subs and testing them:
D:\bortable\throne\Throne.exe				public/private	tcp	[name: Throne]
`D:\bortable\throne\Throne.exe				public/private	udp	[name: Throne]`

**Necessary for connecting with TUN:
D:\bortable\throne\Core				all	tcp	[name: sing-tun (D:\bortable\throne\Core)]
D:\bortable\throne\Core.exe				public/private	tcp	[name: Core]
`D:\bortable\throne\Core.exe				public/private	udp	[name: Core]`

====================================
#Throne2:
**Necessary for updating Subs and testing them:
D:\bortable\throne2\Throne.exe				public/private	tcp	[name: Throne]
`D:\bortable\throne2\Throne.exe			public/private	udp	[name: Throne]`

**Necessary for connecting with TUN:
D:\bortable\throne2\Core				all	tcp	[name: sing-tun (D:\bortable\throne2\Core)]
D:\bortable\throne2\Core.exe				public/private	tcp	[name: Core]
`D:\bortable\throne2\Core.exe				public/private	udp	[name: Core]`

====================================
#V2ray:
**Necessary for connecting with TUN:
D:\bortable\v2ray7\bin\sing_box\sing-box.exe			all	tcp	[name: sing-tun (D:\bortable\v2ray7\bin\sing_box\sing-box.exe)]

========================================================================

**Note1:
Public is Wifi.
Private is Ethernet (Connecting with a Cable).

========================================================================
