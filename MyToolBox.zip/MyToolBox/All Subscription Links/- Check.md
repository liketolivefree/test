**Note:
Any `Domain-type` config from `C` group naming 🔒 [By EbraSha] is fake.

===========================================
#Checking My Subs:
1- When Clash Core says the proxy number N is faulty, you should look for it in line number N+2 in your config file.
2- Check the "short id" with a Clash Core or Client.
  *NOT Accepted "short id"s: "01", "0233", "004", "00e7", "7266e6"
  *Accepted "short id"s: "062f0288c08c", "0b886008af8942c3", "0f704e", "1a", "c7", "13", "0c"
3- Check the "security" item in proxies with TLS.
4- Check the IPs (and remove IR, TR,CN,RU)

===========================================
#Checking a List:
1- remove duplicated
2- sort a-z and remove the unwanted
3- append [qqqqq] to the end of them ( =""&A1&"qqqqq" ) and check [.qqq], [,qqq], [-qqq], [:qqq], [ qqq], [_qqq], [/qqq],...
4- seperate [*.*.*.*.*]
5- seperate [*.*.*.*] and then seperate 1-9 in order to seperate IPs.
6- seperate [*.*] and Delete the remains, 'cause they are not domains or ips.
7- [optional] seperate the cells containing * 
8- if the list is dirty, check for these items:
#
[space]
/
: [**Unless IPv6]
$
|
\
=
^
@
!
,
%
? [~?]
,
;
(
)
'
"
&
+
* [~*]


# For IPv4:
9- Always check for these items:
:
./

10- Always check for duplicated values, like:
1.2.3.4/20
1.2.3.4/21


# For IPv6:
11- Always check for these items:
.
:/
::/
0:0:0:0/

12- Always check for duplicated values, like:
1:2:3:4:5:6:7:8/20
1:2:3:4:5:6:7:8/21

==================================================

