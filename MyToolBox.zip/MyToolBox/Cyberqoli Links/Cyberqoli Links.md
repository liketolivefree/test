#SINGBOX1(BROWSER)
https://sing-box-subscribe-doraemon.vercel.app/config/https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub&file=https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt.json
https://sing-box-subscribe-doraemon.vercel.app/config/https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub&file=https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_l.json
https://sing-box-subscribe-doraemon.vercel.app/config/https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub&file=https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_me.json
https://sing-box-subscribe-doraemon.vercel.app/config/https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub&file=https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_prx7991.json
https://sing-box-subscribe-doraemon.vercel.app/config/https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub&file=https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_rs.json
.........................................................

#SINGBOX2(BROWSER)
https://singbox.nite07.com/convert?data=eyJzdWJzY3JpcHRpb24iOlsiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xpa2V0b2xpdmVmcmVlL2tvYmFiaS9tYWluL3N1YiJdLCJwcm94eSI6W10sImRlbGV0ZSI6IiIsInRlbXBsYXRlIjoiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL25pdGV6cy9zdWIyc2luZy1ib3gvcmVmcy9oZWFkcy9tYXN0ZXIvdGVtcGxhdGVzL2V4YW1wbGUtd2luZG93cy5qc29uIiwicmVuYW1lIjp7fSwiZ3JvdXAtdHlwZSI6InNlbGVjdG9yIiwic29ydCI6InRhZyIsInNvcnQtdHlwZSI6ImFzYyJ9DQo
https://singbox.nite07.com/convert?data=eyJzdWJzY3JpcHRpb24iOlsiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xpa2V0b2xpdmVmcmVlL3Rlc3QvbWFpbi9zIl0sInByb3h5IjpbXSwiZGVsZXRlIjoiIiwidGVtcGxhdGUiOiJodHRwczovL3Jhdy5naXRodWJ1c2VyY29udGVudC5jb20vbml0ZXpzL3N1YjJzaW5nLWJveC9yZWZzL2hlYWRzL21hc3Rlci90ZW1wbGF0ZXMvZXhhbXBsZS13aW5kb3dzLmpzb24iLCJyZW5hbWUiOnt9LCJncm91cC10eXBlIjoic2VsZWN0b3IiLCJzb3J0IjoidGFnIiwic29ydC10eXBlIjoiYXNjIn0
#SINGBOX2(CMD)
sub2sing convert -s https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub -o out.json
sub2sing convert -s https://raw.githubusercontent.com/liketolivefree/test/main/s -o out.json
........................................................

#SINGBOX3(BROWSER)
https://clash2sfa.xmdhs.com/sub?sub=https%3A%2F%2Fraw.githubusercontent.com%2Fliketolivefree%2Fkobabi%2Fmain%2Fprov_clash.yaml
https://oluceps.github.io/clash2sing-box/
#SINGBOX3(CMD)
clash2sing -i prov_clash.yaml
clash2sing -url https://raw.githubusercontent.com/liketolivefree/kobabi/main/prov_clash.yaml
........................................................

#CLASH1(CMD&BROWSER)
http://127.0.0.1:25500/sub?target=clash&url=
http://localhost:25500/sub?target=clash&url=https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub
http://localhost:25500/sub?target=clash&url=https://raw.githubusercontent.com/liketolivefree/test/main/s
.........................................................

#CLASH2(BROWSER)
https://clash.nite07.com/convert/eyJjbGFzaFR5cGUiOjIsInN1YnNjcmlwdGlvbnMiOlsiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xpa2V0b2xpdmVmcmVlL2tvYmFiaS9tYWluL3N1YiJdLCJ1c2VyQWdlbnQiOiIiLCJyZWZyZXNoIjpmYWxzZSwiYXV0b1Rlc3QiOmZhbHNlLCJsYXp5IjpmYWxzZSwibm9kZUxpc3QiOmZhbHNlLCJpZ25vcmVDb3VudHJ5R3JvdXAiOmZhbHNlLCJ1c2VVRFAiOmZhbHNlLCJzb3J0IjoibmFtZWFzYyJ9
https://clash.nite07.com/convert/eyJjbGFzaFR5cGUiOjIsInN1YnNjcmlwdGlvbnMiOlsiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xpa2V0b2xpdmVmcmVlL3Rlc3QvbWFpbi9zIl0sInVzZXJBZ2VudCI6IiIsInJlZnJlc2giOmZhbHNlLCJhdXRvVGVzdCI6ZmFsc2UsImxhenkiOmZhbHNlLCJub2RlTGlzdCI6ZmFsc2UsImlnbm9yZUNvdW50cnlHcm91cCI6ZmFsc2UsInVzZVVEUCI6ZmFsc2UsInNvcnQiOiJuYW1lYXNjIn0
#CLASH2(CMD&BROWSER)
http://127.0.0.1:8011/convert/eyJjbGFzaFR5cGUiOjIsInN1YnNjcmlwdGlvbnMiOlsiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xpa2V0b2xpdmVmcmVlL2tvYmFiaS9tYWluL3N1YiJdLCJ1c2VyQWdlbnQiOiIiLCJyZWZyZXNoIjpmYWxzZSwiYXV0b1Rlc3QiOmZhbHNlLCJsYXp5IjpmYWxzZSwibm9kZUxpc3QiOmZhbHNlLCJpZ25vcmVDb3VudHJ5R3JvdXAiOmZhbHNlLCJ1c2VVRFAiOmZhbHNlLCJzb3J0IjoibmFtZWFzYyJ9
http://127.0.0.1:8011/convert/eyJjbGFzaFR5cGUiOjIsInN1YnNjcmlwdGlvbnMiOlsiaHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2xpa2V0b2xpdmVmcmVlL3Rlc3QvbWFpbi9zIl0sInVzZXJBZ2VudCI6IiIsInJlZnJlc2giOmZhbHNlLCJhdXRvVGVzdCI6ZmFsc2UsImxhenkiOmZhbHNlLCJub2RlTGlzdCI6ZmFsc2UsImlnbm9yZUNvdW50cnlHcm91cCI6ZmFsc2UsInVzZVVEUCI6ZmFsc2UsInNvcnQiOiJuYW1lYXNjIn0

(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)
#Filters
https://raw.githubusercontent.com/liketolivefree/test/main/MyToolBox.zip
https://raw.githubusercontent.com/liketolivefree/filters/main/brave-browser.txt
https://raw.githubusercontent.com/liketolivefree/filters/main/dnscrypt_allowed-names.txt
https://raw.githubusercontent.com/liketolivefree/filters/main/dnscrypt_blocked-names.txt
https://raw.githubusercontent.com/liketolivefree/filters/main/hosts
https://raw.githubusercontent.com/liketolivefree/filters/main/hosts_dns.txt
https://raw.githubusercontent.com/liketolivefree/filters/main/hosts_dns_clash.yaml
https://raw.githubusercontent.com/liketolivefree/filters/main/hosts_dns_sing-box.json
https://raw.githubusercontent.com/liketolivefree/filters/main/hosts_dns_v2ray.txt
https://raw.githubusercontent.com/liketolivefree/filters/main/noscript.json
https://raw.githubusercontent.com/liketolivefree/filters/main/ublock-origin.txt

(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)
#Misc.
https://raw.githubusercontent.com/mahsanet/MahsaFreeConfig/main/telegram/index.json
https://raw.githubusercontent.com/Firmfox/Proxify/main/telegram_proxies/mtproto.txt
https://raw.githubusercontent.com/Firmfox/Proxify/main/telegram_proxies/socks5.txt
https://raw.githubusercontent.com/MhdiTaheri/ProxyCollector/main/proxy.txt
https://raw.githubusercontent.com/itsyebekhe/PSG/main/channelsData/ip_info_cache.json
https://datatracker.ietf.org/doc/html/rfc1034
https://www.rfc-editor.org/rfc/rfc1034.html
https://www.rfc-editor.org/rfc/rfc1034.txt
https://www.rfc-editor.org/rfc/rfc1034.pdf

https://www.gstatic.com/generate_204
https://cp.cloudflare.com/
https://1.1.1.1/cdn-cgi/trace

  * AFRINIC(Africa): https://afrinic.net | https://ftp.afrinic.net/pub/stats/afrinic/delegated-afrinic-extended-latest
  * APNIC(Asia-Pacific): https://apnic.net | https://ftp.apnic.net/stats/apnic/delegated-apnic-extended-latest
  * ARIN(North America): https://arin.net | https://ftp.arin.net/pub/stats/arin/delegated-arin-extended-latest
  * LACNIC(Latin America): https://lacnic.net | https://ftp.lacnic.net/pub/stats/lacnic/delegated-lacnic-extended-latest
  * RIPE NCC(Europe): https://ripe.net | https://ftp.ripe.net/ripe/stats/delegated-ripencc-extended-latest

(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)
#SINGBOX

##Config:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/singbox.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/singbox_l.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/singbox_me.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/singbox_prx7991.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/singbox_rs.json
<><><><><><><><><><><><><><><><><><><><><><><><><><><><>
##Templete:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_l.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_me.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_prx7991.json
https://raw.githubusercontent.com/liketolivefree/kobabi/main/templt_rs.json
<><><><><><><><><><><><><><><><><><><><><><><><><><><><>
##Provider:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/prov_sing.json
<><><><><><><><><><><><><><><><><><><><><><><><><><><><>
##Rule:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/aff.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/aff_me.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/aff_l.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/doki.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/loo.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/oki.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/xal.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/yun.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/yun_me.srs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/wht.srs
<><><><><><><><><><><><><><><><><><><><><><><><><><><><>
##Package:
https://raw.githubusercontent.com/liketolivefree/test/main/singbox.zip
https://raw.githubusercontent.com/liketolivefree/test/main/singbox_l.zip
https://raw.githubusercontent.com/liketolivefree/test/main/singbox_rs.zip

(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)
#META

##Config:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/4mom.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_me.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_me2.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_l.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_l2.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_f.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_f2.yaml
https://raw.githubusercontent.com/liketolivefree/kobabi/main/clash_mt_ir_prov_spr.yaml
<><><><><><><><><><><><><><><><><><><><><><><><><><><><>
##Provider:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/prov_clash.yaml
<><><><><><><><><><><><><><><><><><><><><><><><><><><><>
##Rule:
https://raw.githubusercontent.com/liketolivefree/kobabi/main/aff.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/aff_l.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/aff_me.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/doki.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/loo.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/oki.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/xal.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/yun.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/yun_me.mrs
https://raw.githubusercontent.com/liketolivefree/kobabi/main/wht.mrs
=======================================================
#V2RAY
https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub.txt
https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub
https://raw.githubusercontent.com/liketolivefree/kobabi/main/sub_all.txt


===========================================================================================================
    (poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)
===========================================================================================================







~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷÷


--------------------------------------------------------------------------------------------------------------------------------------------------------------------------


_________________________________________________________________________________________________________________

==================================================================================================


+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


×××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××××


xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx


XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX


||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||


IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII


lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^


<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc


oooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo


CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC


OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO


DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD


QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ


VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV


WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW


YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY


WVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVWVW


Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_Q_


(((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((((|)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))


()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()()


[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[|]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]


|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!|!


pqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpoooooooooooooqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpqpq


/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\


/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\


\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/^|^\/


/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/Z/


T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T__T


U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U__U


v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v^v


wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv^^wv


ooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOooOoo


(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)(@)


(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)(0)


(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C(C


[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]/|\[poq]


(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)(o)


(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)


<~~~~~<-^->~~~~~>|<~~~~~<-^->~~~~~>|<~~~~~<-^->~~~~~>|<~~~~~<-^->~~~~~>|<~~~~~<-^->~~~~~>|


|<~~~~<-o^o->~~~~>|<~~~~<-o^o->~~~~>|<~~~~<-o^o->~~~~>|<~~~~<-o^o->~~~~>|<~~~~<-o^o->~~~~>|


|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]|[I]


~~~~~~~~~~~~~~^*^*^*^*^*^*^*^*^*^*^*^*^'''''''''''''''''''''''''''''''''''''''''''''''''''''''''^*^*^*^*^*^*^*^*^*^*^*^*^*^~~~~~~~~~~~~~~


@@@@@@@@@@@))))))))))))))))))))))))))))))))))_____________=**********=_____________((((((((((((((((((((((((((((((((((@@@@@@@@@@@


_______________________________________________________________________________________________________
  (O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)
'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  (O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)
"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""


===========================================================================================================
  (O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)(O)
===========================================================================================================


========================================================================================================
  /\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\|/\
========================================================================================================


===========================================================================================================
    (poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)/|\(poq)
===========================================================================================================


