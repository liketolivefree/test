#Cores - Supported & Used:
A-1. v2rayN(2dust): (https://github.com/2dust/v2rayN/releases)
`v2rayN(2dust) - all - v7.10.4 (8-3-25)_v2rayN-windows-64-SelfContained.zip` [v2rayN-windows-64-SelfContained]


A-2. xray(XTLS): (https://github.com/XTLS/Xray-core/releases)
`xray(XTLS) - all - v25.3.6 (6-3-25)_Xray-windows-64.zip` [xray - xray.exe]


A-3. singBox(SagerNet): (https://github.com/SagerNet/sing-box/releases)
`singBox(SagerNet) - all - v1.11.5 (11-3-25)_sing-box-xxx-windows-amd64.zip` [sing_box - sing-box.exe]


A-4. mihomo(MetaCubeX): (https://github.com/MetaCubeX/mihomo/releases)
`mihomo(MetaCubeX) - all - v1.19.3 (9-3-3)_mihomo-windows-amd64-compatible-v1.19.3.zip` [mihomo - mihomo-windows-amd64-compatible.exe]


=================================
#Cores - Supported & Not Used:
B-1. v2ray-core(v2fly): (https://github.com/v2fly/v2ray-core/releases)
`v2ray-core(v2fly) - all - v5.28.0 (10-2-25)_v2ray-windows-64.zip` [v2fly_v5 - v2ray.exe]


B-2. hysteria(apernet): (https://github.com/apernet/hysteria/releases)
`hysteria(apernet) - all - v2.6.1 (4-2-25)_hysteria-windows-amd64.exe` [hysteria2 - hysteria-windows-amd64.exe]


B-3. naiveproxy(klzgrad): (https://github.com/klzgrad/naiveproxy/releases)
`naiveproxy(klzgrad) - all - v134.0.6998.39-1 (8-3-25)_naiveproxy-vxxx-1-win-x64.zip` [naiveproxy - naive.exe]


B-4. mieru(enfein): (https://github.com/enfein/mieru/releases)
`mieru(enfein) - all - v3.12.0 (22-2-25)_mieru_xxx_windows_amd64.zip`  [mieru - mieru.exe]


B-5. brook(txthinking): (https://github.com/txthinking/brook/releases)
`brook(txthinking) - all - v20250202 (23-1-25)_brook_windows_amd64.exe` [brook - brook_windows_amd64.exe]


=============================
#Cores - Not Supported & Not Used:
C-1. v2ray-core(v2ray-v2fly): (https://github.com/v2ray/v2ray-core/releases)-(https://github.com/v2fly/v2ray-core/releases/tag/v4.31.0)
`v2ray-core(v2ray-v2fly) - all - v4.31.0 (9-10-20)_windows-64` [v2ctl.exe & wv2ray.exe]


C-2. v2ray-core(SagerNet): (https://github.com/SagerNet/v2ray-core/releases)
`v2ray-core(SagerNet) - all - v5.0.16 (27-6-22)_windows-64` [v2ray.exe]


C-3. juicity(juicity): (https://github.com/juicity/juicity/releases)
`juicity(juicity) - all - v0.4.3 (14-5-24)_juicity-windows-x86_64.zip` [juicity - juicity-client.exe]


C-4. tuic(EAimTY): (https://github.com/EAimTY/tuic/releases)
`tuic(EAimTY) - all - v1.0.0 (12-6-23)_client_tuic-client-1.0.0-x86_64-pc-windows-gnu.exe` [tuic - tuic-client.exe]


==========================================================
#Note:
Since singbox has dropped its support for Geo files & uses Rule_sets, we need to copy some rule_sets in a folder named `srss`:
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geoip-ir.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geosite-ir.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geosite-private.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geosite-category-ads-all.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geoip-malware.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geoip-phishing.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geosite-cryptominers.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geosite-malware.srs
https://raw.githubusercontent.com/Chocolate4U/Iran-sing-box-rules/rule-set/geosite-phishing.srs

================================================
#Plugins
https://github.com/teddysun/xray-plugin/releases
https://github.com/teddysun/xray-plugin-android/releases
https://github.com/teddysun/v2ray-plugin/releases
https://github.com/teddysun/v2ray-plugin-android/releases

https://github.com/xchacha20-poly1305/husi/releases?q=plugin-hysteria

https://github.com/dyhkwong/Exclave/releases?q=brook-plugin
https://github.com/dyhkwong/Exclave/releases?q=hysteria-plugin
https://github.com/dyhkwong/Exclave/releases?q=juicity-plugin
https://github.com/dyhkwong/Exclave/releases?q=mieru-plugin
https://github.com/dyhkwong/Exclave/releases?q=naive-plugin
https://github.com/dyhkwong/Exclave/releases?q=tuic-plugin
https://github.com/dyhkwong/Exclave/releases?q=tuic5-plugin
https://github.com/dyhkwong/Exclave/releases/tag/0.12.0-0-legacy-plugins
https://github.com/dyhkwong/Exclave/releases/tag/0.12.0-0-plugins

https://github.com/enfein/NekoBoxPlugins/releases

https://github.com/klzgrad/naiveproxy/releases

================================================================

